package transaction;

public class Teller extends Thread {

	String tellerName;
	SavingAccount ref;
	double amountToDeposit;
	double amountToWithdraw;
	
	Teller(String name, SavingAccount x, double amt) {
		tellerName= name;
		ref= x;
		amountToDeposit=amt;
		
	}

	Teller(String tellerName, SavingAccount ref, float wamt) {
		super();
		this.tellerName = tellerName;
		this.ref = ref;
		this.amountToWithdraw = wamt;
	}

	@Override
	public String toString() {
		return "Teller [tellerName=" + tellerName + ", ref=" + ref + ", amountToDeposit=" + amountToDeposit + "]";
	}
	
	void depositCash() {
		ref.deposit(amountToDeposit, tellerName);
	}
	void withdrawCash() {
		try {
			ref.withdraw(amountToWithdraw, tellerName);
		} catch (InsufficientFundException e) {
			e.printStackTrace();
		}
	}
	public void run() {
	//depositCash();
		withdrawCash();
	}
}
