package transaction;

public class TestRun {

	public static void main(String[] args) {
		
		SavingAccount sa=new SavingAccount(201, "smg", 15000);
		Teller t1=new Teller("xyz", sa, 10000);
		t1.withdrawCash();
	}

}
