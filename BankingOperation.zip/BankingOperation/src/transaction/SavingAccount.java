package transaction;

public class SavingAccount {

	private int accountNumber;
	private String accountHolderName;
	private double accountBalance;
	
	public SavingAccount(int accountNumber, String accountHolderName, double accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "SavingAccount [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", accountBalance=" + accountBalance + "]";
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getAccountBalance(String tn) {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance, String tn) {
		this.accountBalance = accountBalance;
	}
	
	public synchronized  void deposit(double amountToDeposit, String tn) {
		System.out.println(tn+" Deposit(double) started.....");
		double currentBalance = getAccountBalance(tn);
		System.out.println(tn+" Balance got : "+currentBalance);
		System.out.println(tn+" calculating new balance .....");
		double newBalance = currentBalance + amountToDeposit;
		setAccountBalance(newBalance,tn);
		System.out.println(tn+" Deposit(double) finished.....");
		System.out.println("---------------------");
	}

	public synchronized  void withdraw(double amountToWithdraw, String tn) throws InsufficientFundException {
		System.out.println(tn+" Deposit(double) started.....");
		double currentBalance = getAccountBalance(tn);
		System.out.println(tn+" Balance got : "+currentBalance);
		System.out.println(tn+" calculating new balance .....");
		double newBalance = currentBalance - amountToWithdraw;
		setAccountBalance(newBalance,tn);
		System.out.println(tn+" withdrawing balance(double) finished.....");
		System.out.println("---------------------");
	}

}
