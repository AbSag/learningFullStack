package com.reg.app;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.repositories.ApplicantDetailsRepositoryImpl;



@SpringBootTest
class MySpringBootProject1ApplicationTests {

	
	@Test
	void contextLoads() {
	}

	
	
	
	
	
}
