package com.reg.app.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.exceptions.ApplicantAlreadyExistsException;

@Service
public interface ApplicantDetailsServices {

	public List<ApplicantDetails> fetchAllApplicantsService();
	
	public void addApplicantService(ApplicantDetails appDetails);// throws ApplicantAlreadyExistsException;
	public ApplicantDetails getApplicantByIdService(int id);
	
}
