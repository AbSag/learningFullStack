package com.reg.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.services.MailService;

@RestController
@RequestMapping("/mail")
public class MailController {

	ApplicantDetails appDetails;
	
	@Autowired
	MailService mailService;
	

}
