package com.reg.app.exceptions;

public class ApplicantAlreadyExistsException extends Exception {

	public ApplicantAlreadyExistsException(String msg) {
		super(msg);
	}
}
