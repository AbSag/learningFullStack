package com.reg.app.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.exceptions.ApplicantAlreadyExistsException;

@Repository("bankAppRepo")
public class ApplicantDetailsRepositoryImpl implements ApplicantDetailsRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<ApplicantDetails> getAllApplicant() {
		List<ApplicantDetails> appDetails=null;
		try {
		TypedQuery<ApplicantDetails> query=entityManager.createQuery("from ApplicantDetails", ApplicantDetails.class);
		appDetails = query.getResultList();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return appDetails;
	}
	
	@Override
	public ApplicantDetails getApplicantById(int id) {
		
		ApplicantDetails appDetails=null;
		try {
			appDetails=entityManager.find(ApplicantDetails.class,id);
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return appDetails;
	}
	
	@Transactional
	public void insertApplicant(ApplicantDetails appDetails) {//throws ApplicantAlreadyExistsException {
		//appDetails=entityManager.find(ApplicantDetails.class, appDetails.getAppId());
//		if(appDetails!=null) {
//			throw new ApplicantAlreadyExistsException("This Mobile Already Exists");
//		}
		entityManager.persist(appDetails);
	}
}
