package com.reg.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.repositories.ApplicantDetailsRepository;

@Service("appDetailsService")
public class ApplicantDetailsServiceImpl implements ApplicantDetailsServices {

	@Autowired
	ApplicantDetailsRepository appDetailsRepo;
	
	@Override
	public List<ApplicantDetails> fetchAllApplicantsService() {
		List<ApplicantDetails> appDetails=appDetailsRepo.getAllApplicant();
		return appDetails;
	}

	@Override
	public void addApplicantService(ApplicantDetails appDetails) {// throws ApplicantAlreadyExistsException {
		
		appDetailsRepo.insertApplicant(appDetails);
		
		
//		try {
//			appDetailsRepo.insertApplicant(appDetails);	
//		}
//		catch(ApplicantAlreadyExistsException e) {
//			throw(e);
//		}
			
	}

	public ApplicantDetails getApplicantByIdService(int id) {
		return appDetailsRepo.getApplicantById(id);
	}

}
