package com.reg.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.exceptions.ApplicantAlreadyExistsException;
import com.reg.app.services.ApplicantDetailsServices;
import com.reg.app.services.MailService;

@CrossOrigin
@RestController
@RequestMapping("/appDetails")
public class ApplicantController {

	@Autowired
	ApplicantDetailsServices appDetailsService;
	
	ApplicantDetails appDetails;
	
	@Autowired
	MailService mailService;
	
	@RequestMapping("/")
	public List<ApplicantDetails> allApplicant(){
		System.out.println("allApplicant() is invoked....");
		return appDetailsService.fetchAllApplicantsService();
	}
	
	@RequestMapping("/{appid}")
	public ApplicantDetails allApplicantByAppId(@PathVariable("appid") int APPLICANT_ID){
		System.out.println("allApplicant() is invoked....");
		return appDetailsService.getApplicantByIdService(APPLICANT_ID);
	}
	
	@PostMapping("/addApplicant")
	public void addNewApplicant(@RequestBody ApplicantDetails appDetailsBody ) {// throws ApplicantAlreadyExistsException {
		System.out.println("addApplicant() is invoked....");
		appDetailsService.addApplicantService(appDetailsBody);
		
//		try {
//			appDetailsService.addApplicantService(appDetailsBody);
//		} 
//		catch (ApplicantAlreadyExistsException e) {
//				throw (e);
//			
//		}
	}

	@RequestMapping("/send/{email}")
	public String sendEmailTo(@PathVariable("email") String emailTo) {
		System.out.println("/send to "+emailTo);
		mailService.sendMail("Thank you for applying with us....you can check your "
				+ "status with below credentials  ", appDetails.getEmailId());
		
		return "email sent";
	}
}
