package com.reg.app.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.reg.app.entity.ApplicantDetails;
import com.reg.app.exceptions.ApplicantAlreadyExistsException;


@Repository
public interface ApplicantDetailsRepository {

	public void insertApplicant(ApplicantDetails appId) ;//throws ApplicantAlreadyExistsException;
	public List<ApplicantDetails> getAllApplicant();
	public ApplicantDetails getApplicantById(int id) ;
	
}
