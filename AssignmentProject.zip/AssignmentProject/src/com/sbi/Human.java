package com.sbi;

public interface Human extends LivingBeing {

	void think();
	void quest();
	
	
}
