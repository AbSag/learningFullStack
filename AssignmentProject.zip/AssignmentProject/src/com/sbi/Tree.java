package com.sbi;

public class Tree implements LivingBeing {

	@Override
	public void breathIn() {
		System.out.println("tree breathin...");
		
	}

	@Override
	public void breathOut() {

		System.out.println("tree breathout...");
		
	}
	@Override
	public void movingLivingBeing() {
		System.out.println("trees doesn't move generally ");
		
	}

	@Override
	public void nonMovingLivingBeing() {
		System.out.println("trees belong to this type");
		
	}
}
class FruitGivingTree {
		void mango() {
			System.out.println("mango tree gives mango");
		}
	}
class FlowerGivingTree {
		void lily() {
			System.out.println("Lily flowers");
		}
	}

	

