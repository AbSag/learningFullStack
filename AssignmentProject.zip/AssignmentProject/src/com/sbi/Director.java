package com.sbi;

public class Director extends Manager {

	void directs() {
		System.out.println("director directs the managers");
	}
	
}
