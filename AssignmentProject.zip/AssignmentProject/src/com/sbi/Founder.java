package com.sbi;

public class Founder {

	void found() {
		System.out.println("founder kept the very foundation of this company");
	}
}
