package com.sbi;

public class TypesOfAnimal implements LivingBeing {
	
	@Override
	public void breathIn() {
			System.out.println("animals do breathIn");
	}

	@Override
	public void breathOut() {
		System.out.println("animals do breathOut");

	}
//	void herbivores() {
//	System.out.println("Herbi eats plant based kind...");
//}
//
//void carnivores() {
//	System.out.println("Carni eats meat based food...");
//}
//
//void omnivores() {
//	System.out.println("Omni eats both kind...");
//}

	@Override
	public void movingLivingBeing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void nonMovingLivingBeing() {
		// TODO Auto-generated method stub
		
	}
}
