package com.sbi;

public class Executive extends Employee{

	void ActsOnBehalf() {
		System.out.println("executive put plans into actions");
	}
}
