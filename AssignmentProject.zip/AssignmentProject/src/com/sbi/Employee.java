package com.sbi;

public class Employee extends Person {

	public void doesJob() {
		System.out.println("employee does regular job");
	}

	public void takesLeave() {
		System.out.println("employee takes leave");
	}

	void relax() {
		System.out.println("employee relax");
	}

}
