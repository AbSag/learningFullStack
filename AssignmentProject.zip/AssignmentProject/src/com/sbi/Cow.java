package com.sbi;

public class Cow extends TypesOfAnimal {

	void eat(boolean plants) {
		System.out.println("cow is a herbivores animal");
	}

	Milk eat(Grass g) {
		System.out.println("cow produces milk");
		Milk m = new Milk();
		return m;
	}

}

class Grass {
	void greenGrass() {
		System.out.println("cow uses green grass to eat	");
	}
}

class Milk {
	void milking() {
		System.out.println("process to get milk");
	}
	
	public void breathIn() {
			System.out.println("animals do breathIn so thus cow");
	}

	
	public void breathOut() {
		System.out.println("animals do breathOut so thus cow");

	}

}


