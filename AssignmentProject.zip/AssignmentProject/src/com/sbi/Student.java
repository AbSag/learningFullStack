package com.sbi;

public class Student extends Person {
	@Override
	void doesJob() {
		System.out.println("Sometime studentlife have to do job");
	}

	@Override
	void takesLeave() {
		System.out.println("student takes leave");
	}

	@Override
	void relax() {
		System.out.println("student needs to relax");
	}

	Result giveExam(Study st) {
		return null;

	}
}

class Result extends Student {
	Human result(Human h) {
		System.out.println("student always come with a result");
		return h;
	}
}

class Study {
	LivingBeing examPaper() {
		LivingBeing lb = new Student();
		System.out.println("Remember, there is always an exam at the end");
		return lb;
	}
}
