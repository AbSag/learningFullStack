package com.sbi;

public class TestRun {

	public static void main(String[] args) {
		
		Cow c=new Cow();
		Grass g=new Grass();
		Milk m=new Milk();
		m.breathIn();
		m.breathOut();
		g.greenGrass();
		m.milking();
		c.eat(g);
		System.out.println("--------");
		
		Human h=new Student();;
		Student s=new Student();
		Study st = new Study();
		
		s.giveExam(st);
		Result r=new Result();
		st.examPaper();
		r.result(h);
		
		System.out.println("--------");
	}
}
