package com.sbi;

public interface LivingBeing {

	void breathIn();
	void breathOut();
	void movingLivingBeing();
	void nonMovingLivingBeing();
}
class basedOnMovements implements LivingBeing{

	@Override
	public void breathIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void breathOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void movingLivingBeing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void nonMovingLivingBeing() {
		// TODO Auto-generated method stub
		
	}
	
}