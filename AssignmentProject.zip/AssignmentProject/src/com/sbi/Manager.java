package com.sbi;

public class Manager extends Executive{

	void manage() {
		System.out.println("manager responsible for managing");
	}
	
}
