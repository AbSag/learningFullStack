package com.sbi;

abstract class Person implements Human{
	
	abstract void doesJob();
	abstract void takesLeave();
	abstract void relax();
	
	public void breathIn() {
	}

	@Override
	public void breathOut() {
	}

	@Override
	public void movingLivingBeing() {
	}

	@Override
	public void nonMovingLivingBeing() {
	}
	
	public void think(){
		System.out.println("Person do think");
		}
	public void quest() {
		System.out.println("Person has quest for something");
	}

}

